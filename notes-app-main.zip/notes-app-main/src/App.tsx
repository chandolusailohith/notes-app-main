import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginScreen } from './components/Auth/LoginScreen';
import { SignupScreen } from './components/Auth/SignupScreen';
import { NotesListScreen } from './components/Notes/NotesListScreen';
import { NoteEditor } from './components/Notes/NoteEditor';
import { Note } from './types';
import { storage } from './utils/storage';

type Screen = 'login' | 'signup' | 'notes' | 'editor';

const AppContent = () => {
  const { user } = useAuth();
  const [screen, setScreen] = useState<Screen>('login');
  const [notes, setNotes] = useState<Note[]>([]);
  const [currentNote, setCurrentNote] = useState<Note | null>(null);

  useEffect(() => {
    if (user) {
      setScreen('notes');
      loadNotes();
    } else {
      setScreen('login');
    }
  }, [user]);

  const loadNotes = () => {
    if (user) {
      const userNotes = storage.getNotes(user.id);
      setNotes(userNotes);
    }
  };

  const handleSaveNote = (note: Note) => {
    storage.saveNote(note);
    loadNotes();
    setScreen('notes');
    setCurrentNote(null);
  };

  const handleDeleteNote = (noteId: string) => {
    storage.deleteNote(noteId);
    loadNotes();
  };

  const handleCreateNote = () => {
    setCurrentNote(null);
    setScreen('editor');
  };

  const handleEditNote = (note: Note) => {
    setCurrentNote(note);
    setScreen('editor');
  };

  const handleCancelEdit = () => {
    setCurrentNote(null);
    setScreen('notes');
  };

  if (!user) {
    return screen === 'signup' ? (
      <SignupScreen onSwitchToLogin={() => setScreen('login')} />
    ) : (
      <LoginScreen onSwitchToSignup={() => setScreen('signup')} />
    );
  }

  if (screen === 'editor') {
    return (
      <NoteEditor
        note={currentNote}
        onSave={handleSaveNote}
        onCancel={handleCancelEdit}
      />
    );
  }

  return (
    <NotesListScreen
      notes={notes}
      onCreateNote={handleCreateNote}
      onEditNote={handleEditNote}
      onDeleteNote={handleDeleteNote}
    />
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
