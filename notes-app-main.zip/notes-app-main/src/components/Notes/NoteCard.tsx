import { Trash2, Image as ImageIcon } from 'lucide-react';
import { Note } from '../../types';

interface NoteCardProps {
  note: Note;
  onEdit: () => void;
  onDelete: () => void;
  index: number;
}

export const NoteCard = ({ note, onEdit, onDelete, index }: NoteCardProps) => {
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this note?')) {
      onDelete();
    }
  };

  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  };

  const colors = [
    'from-pink-200 to-pink-300',
    'from-blue-200 to-blue-300',
    'from-green-200 to-green-300',
    'from-yellow-200 to-yellow-300',
    'from-purple-200 to-purple-300',
    'from-teal-200 to-teal-300',
  ];

  const colorClass = colors[index % colors.length];

  return (
    <div
      onClick={onEdit}
      className="bg-white rounded-2xl shadow-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl animate-slide-up"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      {note.image ? (
        <div className="h-48 overflow-hidden">
          <img
            src={note.image}
            alt={note.title}
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
          />
        </div>
      ) : (
        <div className={`h-48 bg-gradient-to-br ${colorClass} flex items-center justify-center`}>
          <ImageIcon className="w-16 h-16 text-white opacity-50" />
        </div>
      )}

      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-800 flex-1 line-clamp-2">
            {note.title || 'Untitled'}
          </h3>
          <button
            onClick={handleDelete}
            className="ml-2 p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-200"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>

        <p className="text-gray-600 mb-4 line-clamp-3">
          {truncateText(note.body, 120)}
        </p>

        <div className="text-sm text-gray-400">
          {new Date(note.updatedAt).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          })}
        </div>
      </div>
    </div>
  );
};
