import { useState, useMemo } from 'react';
import { Plus, Search, LogOut, ArrowUpDown, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Note, SortOption } from '../../types';
import { NoteCard } from './NoteCard';

interface NotesListScreenProps {
  notes: Note[];
  onCreateNote: () => void;
  onEditNote: (note: Note) => void;
  onDeleteNote: (noteId: string) => void;
}

export const NotesListScreen = ({
  notes,
  onCreateNote,
  onEditNote,
  onDeleteNote,
}: NotesListScreenProps) => {
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('newest');
  const [showSortMenu, setShowSortMenu] = useState(false);

  const filteredAndSortedNotes = useMemo(() => {
    let result = [...notes];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (note) =>
          note.title.toLowerCase().includes(query) ||
          note.body.toLowerCase().includes(query)
      );
    }

    result.sort((a, b) => {
      switch (sortOption) {
        case 'newest':
          return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
        case 'oldest':
          return new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
        case 'a-z':
          return a.title.localeCompare(b.title);
        case 'z-a':
          return b.title.localeCompare(a.title);
        default:
          return 0;
      }
    });

    return result;
  }, [notes, searchQuery, sortOption]);

  const sortOptions = [
    { value: 'newest' as SortOption, label: 'Newest First' },
    { value: 'oldest' as SortOption, label: 'Oldest First' },
    { value: 'a-z' as SortOption, label: 'Title (A-Z)' },
    { value: 'z-a' as SortOption, label: 'Title (Z-A)' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-yellow-50">
      <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-orange-500 to-pink-600 bg-clip-text text-transparent">
                My Notes
              </h1>
              <p className="text-gray-600 mt-1">Welcome back, {user?.username}!</p>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 text-gray-700"
            >
              <LogOut className="w-5 h-5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search notes..."
                className="w-full pl-12 pr-4 py-3 bg-white border-2 border-gray-200 rounded-xl focus:border-orange-400 focus:outline-none transition-all duration-300 shadow-sm"
              />
            </div>

            <div className="relative">
              <button
                onClick={() => setShowSortMenu(!showSortMenu)}
                className="flex items-center gap-2 px-6 py-3 bg-white border-2 border-gray-200 rounded-xl hover:border-orange-400 transition-all duration-300 shadow-sm w-full sm:w-auto justify-center"
              >
                <ArrowUpDown className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-700">Sort</span>
              </button>

              {showSortMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-10 animate-scale-in">
                  {sortOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setSortOption(option.value);
                        setShowSortMenu(false);
                      }}
                      className={`w-full text-left px-4 py-3 hover:bg-orange-50 transition-colors ${
                        sortOption === option.value ? 'bg-orange-100 text-orange-700 font-semibold' : 'text-gray-700'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {filteredAndSortedNotes.length === 0 ? (
          <div className="text-center py-16 animate-fade-in">
            <div className="bg-gradient-to-br from-orange-400 to-pink-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <ImageIcon className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              {searchQuery ? 'No notes found' : 'No notes yet'}
            </h3>
            <p className="text-gray-500 mb-6">
              {searchQuery ? 'Try a different search term' : 'Create your first note to get started'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredAndSortedNotes.map((note, index) => (
              <NoteCard
                key={note.id}
                note={note}
                onEdit={() => onEditNote(note)}
                onDelete={() => onDeleteNote(note.id)}
                index={index}
              />
            ))}
          </div>
        )}

        <button
          onClick={onCreateNote}
          className="fixed bottom-6 right-6 bg-gradient-to-r from-orange-500 to-pink-600 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transform transition-all duration-300 hover:scale-110 hover:rotate-90 z-20"
        >
          <Plus className="w-8 h-8" />
        </button>
      </div>
    </div>
  );
};
