import { useState, useRef } from 'react';
import { ArrowLeft, Save, Camera, Image as ImageIcon, X } from 'lucide-react';
import { Note } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface NoteEditorProps {
  note: Note | null;
  onSave: (note: Note) => void;
  onCancel: () => void;
}

export const NoteEditor = ({ note, onSave, onCancel }: NoteEditorProps) => {
  const { user } = useAuth();
  const [title, setTitle] = useState(note?.title || '');
  const [body, setBody] = useState(note?.body || '');
  const [image, setImage] = useState(note?.image || '');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!title.trim() && !body.trim()) {
      alert('Please add a title or body to your note');
      return;
    }

    const now = new Date().toISOString();
    const savedNote: Note = {
      id: note?.id || crypto.randomUUID(),
      userId: user!.id,
      title: title.trim() || 'Untitled',
      body: body.trim(),
      image: image || undefined,
      createdAt: note?.createdAt || now,
      updatedAt: now,
    };

    onSave(savedNote);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-teal-50">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden animate-fade-in">
          <div className="bg-gradient-to-r from-cyan-500 to-teal-600 p-6">
            <div className="flex items-center justify-between">
              <button
                onClick={onCancel}
                className="flex items-center gap-2 text-white hover:bg-white/20 px-4 py-2 rounded-xl transition-all duration-300"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="hidden sm:inline">Back</span>
              </button>
              <h2 className="text-2xl font-bold text-white">
                {note ? 'Edit Note' : 'New Note'}
              </h2>
              <button
                onClick={handleSave}
                className="flex items-center gap-2 bg-white text-teal-600 px-6 py-2 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <Save className="w-5 h-5" />
                <span className="hidden sm:inline">Save</span>
              </button>
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700">Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter note title..."
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-teal-400 focus:outline-none transition-all duration-300 text-xl font-semibold"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700">Content</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Start writing your note..."
                rows={12}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-teal-400 focus:outline-none transition-all duration-300 resize-none"
              />
            </div>

            <div className="space-y-4">
              <label className="text-sm font-semibold text-gray-700">Image</label>

              {image && (
                <div className="relative rounded-xl overflow-hidden group">
                  <img
                    src={image}
                    alt="Note"
                    className="w-full h-64 object-cover"
                  />
                  <button
                    onClick={() => setImage('')}
                    className="absolute top-4 right-4 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-all duration-300 opacity-0 group-hover:opacity-100"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              )}

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <ImageIcon className="w-5 h-5" />
                  Choose from Gallery
                </button>

                <button
                  onClick={() => cameraInputRef.current?.click()}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-teal-500 to-green-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <Camera className="w-5 h-5" />
                  Take Photo
                </button>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />

              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleImageSelect}
                className="hidden"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
