import { User, Note } from '../types';

const USERS_KEY = 'notes_app_users';
const NOTES_KEY = 'notes_app_notes';
const CURRENT_USER_KEY = 'notes_app_current_user';

export const storage = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveUsers: (users: User[]) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  addUser: (user: User) => {
    const users = storage.getUsers();
    users.push(user);
    storage.saveUsers(users);
  },

  findUser: (username: string): User | undefined => {
    const users = storage.getUsers();
    return users.find(u => u.username === username);
  },

  getCurrentUser: (): User | null => {
    const data = localStorage.getItem(CURRENT_USER_KEY);
    return data ? JSON.parse(data) : null;
  },

  setCurrentUser: (user: User | null) => {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  },

  getNotes: (userId: string): Note[] => {
    const data = localStorage.getItem(NOTES_KEY);
    const allNotes: Note[] = data ? JSON.parse(data) : [];
    return allNotes.filter(note => note.userId === userId);
  },

  saveNote: (note: Note) => {
    const data = localStorage.getItem(NOTES_KEY);
    const allNotes: Note[] = data ? JSON.parse(data) : [];
    const index = allNotes.findIndex(n => n.id === note.id);

    if (index >= 0) {
      allNotes[index] = note;
    } else {
      allNotes.push(note);
    }

    localStorage.setItem(NOTES_KEY, JSON.stringify(allNotes));
  },

  deleteNote: (noteId: string) => {
    const data = localStorage.getItem(NOTES_KEY);
    const allNotes: Note[] = data ? JSON.parse(data) : [];
    const filtered = allNotes.filter(n => n.id !== noteId);
    localStorage.setItem(NOTES_KEY, JSON.stringify(filtered));
  },
};
